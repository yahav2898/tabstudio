namespace UnoRecommended.Models;

public record AppConfig
{
    public string? Environment { get; init; }
}
