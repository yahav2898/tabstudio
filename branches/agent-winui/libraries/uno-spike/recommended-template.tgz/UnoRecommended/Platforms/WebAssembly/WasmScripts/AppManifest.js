var UnoAppManifest = {
    displayName: "UnoRecommended"
}
